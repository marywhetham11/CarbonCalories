

window.addEventListener("load", function(event) {
    
    
        
     function getItems(){
        setTimeout(() => {
            var items = document.getElementsByClassName("css-9s1jr8 ei50f4d0");
            
            
            
            
            var itemsImg = document.getElementsByClassName("css-128ipej");
            var itemName = document.getElementsByClassName("ei50f4d1 css-1gngjqe elkyjhv0");
            var scoreSpot = document.getElementsByClassName("css-19vs47a ei50f4d13")
            var scoreSpots = []

            for(var j = 1; j < scoreSpot.length; j += 2 ){

                scoreSpots.push(scoreSpot[j])
            }
            console.log(scoreSpots)
            itemIDs = []
            itemsImgs = []
            itemNames = []

            for(var i = 0; i < items.length; i++){
                
                itemIDs.push(items[i].id) 
                itemsImgs.push(itemsImg[i].style)
                itemNames.push(itemName[i].innerHTML)

            }
            
            let message ={
                id : 'content',
                itemArray : itemIDs,
                itemImgArray : itemsImgs,
                itemNameArray : itemNames
            }
            console.log(message)
            chrome.runtime.sendMessage(message, function(response){
                itemScores = JSON.parse(response)
                console.log(itemScores.scores)
                for(var j = 0; j < scoreSpots.length; j++){
                    var webpageScore = document.createElement("p") 
                    var actualScore = document.createElement("strong")
                    var arrowContainer =  document.createElement("div")
                    var arrow = document.createElement("i")
                    arrow.setAttribute("style", "border: solid black; border-width: 0 3px 3px 0; display: inline-block; padding: 3px; transform: rotate(-135deg); -webkit-transform: rotate(-135deg);")
                    arrowContainer.appendChild(arrow)
                    var scoreContainer = document.createElement('div')
                    var gradient = document.createElement("div")
                    var twoContainer = document.createElement('div')
                    var arrowSpot = ((itemScores.scores[j] - 4)/ 6) * 170
                    console.log(arrowSpot) 

                    actualScore.innerHTML = itemScores.scores[j].toFixed(1)
                    arrowContainer.setAttribute("style", "text-indent: " + arrowSpot + "px;")
                    twoContainer.setAttribute("style"," position: absolute; bottom: -10px; width: 170px; ")
                    gradient.setAttribute("style", "background-image: linear-gradient(to right, red , #00FF7F);height: 24px;width: 174px; margin-top: 10px;")

                    if (itemScores.scores[j] >= 7) {
                        actualScore.setAttribute("style", "margin: 0;  color: green; ")
                    }else if(itemScores.scores[j] < 7 && itemScores.scores[j] >= 5){
                        actualScore.setAttribute("style", "margin: 0;  color: yellow;")
                    }else{
                        actualScore.setAttribute("style", "margin: 0; color: red;")
                    }

                    console.log(actualScore)
                    webpageScore.innerHTML ="Rating: " + actualScore.outerHTML
                    webpageScore.setAttribute("style", "margin: 0; text-align: center;")
                    scoreContainer.setAttribute("style", "height: 24px; width: 170px; background: rgb(197, 191, 189); border: 2px solid #000000; justify-content: center;")
                    scoreContainer.appendChild(webpageScore)
                    twoContainer.appendChild(scoreContainer)
                    twoContainer.appendChild(gradient)
                    twoContainer.appendChild(arrowContainer)
                    scoreSpots[j].appendChild(twoContainer)
                }
            });

            

            
        }, 1300);

    }
    getItems()

    document.getElementsByClassName('css-dldxm2 edzik9p0')[0].addEventListener("click", function(event){
        console.log('checkout button pressed')
        let message ={
            id :'send'
        }
        chrome.runtime.sendMessage(message)
    })
    var removeButtons = document.getElementsByClassName('css-bssxbt ei50f4d14')
    for(var i = 0; i < removeButtons.length; i++){
        removeButtons[i].addEventListener("click", ButtonsDeleted)
    }

    function ButtonsDeleted(){
        console.log('itemRemoved')
        getItems()
    }
})



