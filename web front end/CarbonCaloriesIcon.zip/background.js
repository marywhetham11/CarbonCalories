

chrome.runtime.onMessage.addListener(receiver);

var items = "No Items";
var itemsImg = "No Items"
var user = {username : "",
password : ""}
var loggedIn = false
var itemScores = ""
var itemNames = []
var finished = false

function receiver (message, sender, sendResponse){
    if (message.id == 'content'){
        items = message.itemArray;
        itemsImg = message.itemImgArray
        itemNames = message.itemNameArray
        console.log(itemNames)
        console.log('1')
        const sendFile ={
            ids: items
        } 
        const jsonString = JSON.stringify(sendFile)
        
        function promiseJax(jsonString){
            
            console.log(jsonString)
            

            return new Promise(function(resolve, reject){
                var scores = new XMLHttpRequest()
                scores.onload = function () {
                    const data = JSON.parse(scores.response)
                    itemScores = data.scores 
                    console.log(itemScores)
                    updatePopup()
                    resolve(this)
                }
                scores.open("POST", "https://carbon-calories.nn.r.appspot.com/getscores")
                scores.setRequestHeader("Content-Type", "application/json")
                scores.send(jsonString)
            });
            
            
            
        }

        promiseJax(jsonString).then(function(scores){
            console.log(scores.response)
            sendResponse(scores.response)
        })
        
        
        
        
        
    }else if (message.id == 'popup'){
        user.username = message.username
        user.password = message.password
        loggedIn = true
        logIn()
        console.log(loggedIn)
    }else{
        console.log("send to backend")
        if(loggedIn == true){

            const sendScores ={
                ids: items,
                item_scores: itemScores.scores,
                username: user.username
            } 
            console.log(sendScores)
            const jsonStringScores = JSON.stringify(sendScores)
            var logScores = new XMLHttpRequest()
            logScores.open("POST", "https://carbon-calories.nn.r.appspot.com/submitscores")
            logScores.setRequestHeader("Content-Type", "application/json")
            logScores.send(jsonStringScores)

            logScores.onload = function (){
                const asdf = JSON.stringify(logScores.response)
                console.log(asdf)
            }
        }
        
        
    }
       
    return true
    
}; 

function updatePopup(){
    let update ={
        id :'removal'
    }
    console.log(update)
    chrome.runtime.sendMessage(update)
}

function logIn(){
    console.log("log in function reached")
    let logInMessage ={
        id: 'logIn'
    }
    chrome.runtime.sendMessage(logInMessage)
}

